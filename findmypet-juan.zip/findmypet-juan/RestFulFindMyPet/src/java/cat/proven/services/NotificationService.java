package cat.proven.services;

import cat.proven.entities.NotificationClass;
import cat.proven.entities.persistence.NotificationADO;
import java.util.List;

public class NotificationService {
    
    public List<NotificationClass> getNotifications(){
        NotificationADO nAdo = new NotificationADO();
        List<NotificationClass> notifications = nAdo.getNotifications();
        return notifications;
    }
    
    public List<NotificationClass> getUserNotifications(int id_user){
        NotificationADO nAdo = new NotificationADO();
        List<NotificationClass> notifications = nAdo.searchUserNotifications(id_user);
        return notifications;
    }
    
    public int addNotification(NotificationClass n){
        NotificationADO nAdo = new NotificationADO();
        int result = nAdo.addNotification(n);
        return result;
    }
    
    public int modifyNotification(NotificationClass n){
        NotificationADO nAdo = new NotificationADO();
        int result = nAdo.modifyNotification(n);
        return result;
    }
    
    public int modifyNotificationActive(int id_notification){
        NotificationADO nAdo = new NotificationADO();
        int result = nAdo.modifyNotificationActive(id_notification);
        return result;
    }
}
