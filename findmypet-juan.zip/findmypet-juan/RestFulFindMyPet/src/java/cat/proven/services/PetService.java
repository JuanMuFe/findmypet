package cat.proven.services;

import cat.proven.entities.PetClass;
import cat.proven.entities.persistence.PetADO;
import java.util.List;

public class PetService {
    
    public PetService(){  }
        
    public int addPet(PetClass p){
        PetADO pADO = new PetADO();        
        return pADO.addPet(p);
    }   
    
    public int modifyPet(int id_user, PetClass p){
        PetADO pADO = new PetADO();
        return pADO.modifyPet(id_user, p);
    }
    
    public int deletePet(Integer id){
        PetADO pADO = new PetADO();
        return pADO.deletePet(id);
    }
    
    public List<PetClass> searchPet(String toSearch){
        PetADO pADO = new PetADO();
        return pADO.searchPet(toSearch);
    }
}
