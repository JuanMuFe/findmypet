package cat.proven.services;

import cat.proven.entities.ReportClass;
import cat.proven.entities.persistence.ReportADO;
import java.util.List;


public class ReportService {
    public ReportService(){  }
    
    public int addReport(ReportClass r){
        ReportADO pADO = new ReportADO();        
        return pADO.insertReport(r);
    } 
    
    public int modifyReport(ReportClass r){
        ReportADO pADO = new ReportADO();        
        return pADO.updateReport(r);
    }
    
    public int modifyReportFinished(ReportClass r){
        ReportADO pADO = new ReportADO();        
        return pADO.updateReportFinished(r);
    }
    
    public List<ReportClass> searchOwnerReports(int id_owner){
        ReportADO pADO = new ReportADO();        
        return pADO.searchOwnerReports(id_owner);
    }
    
    public List<ReportClass> searchPetReports(int id_pet){
        ReportADO pADO = new ReportADO();        
        return pADO.searchPetReports(id_pet);
    }
}
