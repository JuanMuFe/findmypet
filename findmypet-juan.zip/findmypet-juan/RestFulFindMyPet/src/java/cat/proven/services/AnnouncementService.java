package cat.proven.services;

import cat.proven.entities.AnnouncementClass;
import cat.proven.entities.persistence.AnnouncementADO;
import java.util.List;

public class AnnouncementService {
    
    public List<AnnouncementClass> getAnnouncements(){
        AnnouncementADO aAdo = new AnnouncementADO();
        List<AnnouncementClass> announcements = aAdo.getAnnouncements();
        return announcements;
    }
    
    public List<AnnouncementClass> getUserAnnouncements(int id_user){
        AnnouncementADO aAdo = new AnnouncementADO();
        List<AnnouncementClass> announcements = aAdo.getOwnerAnnouncements(id_user);
        return announcements;
    }
    
     public int insertAnnouncement(AnnouncementClass a){
        AnnouncementADO aAdo = new AnnouncementADO();
        int result = aAdo.addAnnouncement(a);
        return result;
    }
     
     public int deleteAnnouncement(int id){
        AnnouncementADO aAdo = new AnnouncementADO();
        int result = aAdo.deleteAnnouncement(id);
        return result;
    }
     
     public int modifyAnnouncement(AnnouncementClass a){
        AnnouncementADO aAdo = new AnnouncementADO();
        int result = aAdo.modifyAnnouncement(a);
        return result;
    }
}
