package cat.proven.services;

import cat.proven.entities.ParkClass;
import cat.proven.entities.persistence.ParkADO;
import java.util.List;

public class ParkService {
    public ParkService(){}
    
    public int modify(ParkClass p){
        ParkADO pADO = new ParkADO();
        return pADO.modifyPark(p);
    }
    
    public int add(ParkClass p){
        ParkADO pADO = new ParkADO();
        return pADO.addPark(p);
    }
    
    public List<ParkClass> get(){
        ParkADO pADO = new ParkADO();
        return pADO.getParks();
    }
    
    public int delete(int id){
        ParkADO pADO = new ParkADO();
        return pADO.delete(id);
    }
}
