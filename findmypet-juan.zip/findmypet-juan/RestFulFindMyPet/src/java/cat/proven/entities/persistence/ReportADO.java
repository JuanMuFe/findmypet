package cat.proven.entities.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cat.proven.entities.ConnectionDB;
import cat.proven.entities.OwnerClass;
import cat.proven.entities.PetClass;
import cat.proven.entities.ReportClass;

/**
 * Created by Alumne on 30/04/2016.
 */
public class ReportADO {

    private final String QUERY_SELECT_OWNER_REPORTS = "SELECT * FROM `report` WHERE `id_owner`=?";
    private final String QUERY_SELECT_PET_REPORTS = "SELECT * FROM `report` WHERE `id_pet`=?";
    private final String QUERY_INSERT_REPORT = "INSERT INTO `report` (`id_owner`,`id_pet`,`entry_date`, `location`, `extra`) VALUES (?,?,?,?,?)";
    private final String QUERY_UPDATE_REPORT = "UPDATE `report` SET `location`=?, `extra`=? WHERE `id`=?";
    private final String QUERY_UPDATE_REPORT_FINISHED = "UPDATE `report` SET `finished`=? WHERE `id`=?";

    public ReportADO(){ }

    public int updateReport(ReportClass r)
    {
        int result = -1;

        PreparedStatement st=null;
        try{
            if(r!=null)
            {

                ConnectionDB db = new ConnectionDB();
                Connection conn = db.getConnection();
                if (conn != null){
                    st = conn.prepareStatement(QUERY_UPDATE_REPORT);
                    st.setString(1,r.getLocation());
                    st.setString(2,r.getExtra());
                    st.setInt(3,r.getId());

                    result = st.executeUpdate();
                }
            }
        } catch (SQLException | ClassNotFoundException e){
            result = 0;
        }

        return result;
    }

    public int updateReportFinished(ReportClass r)
    {
        int result = -1;

        PreparedStatement st=null;
        try{
            if(r!=null)
            {

                ConnectionDB db = new ConnectionDB();
                Connection conn = db.getConnection();
                if (conn != null){
                    st = conn.prepareStatement(QUERY_UPDATE_REPORT_FINISHED);
                    st.setInt(1, 1);
                    st.setInt(2,r.getId());

                    result = st.executeUpdate();
                }
            }
        } catch (SQLException | ClassNotFoundException e){
            result = 0;
        }

        return result;
    }
    
    public List<ReportClass> searchOwnerReports(int id_owner){
        int i = 1;
        List<ReportClass> reportList = new ArrayList<>();
        ReportClass report=null;

        try{
            ConnectionDB db = new ConnectionDB();
            Connection conn = null;
            try {
                conn = db.getConnection();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            if (conn != null)
            {
                PreparedStatement st = conn.prepareStatement(QUERY_SELECT_OWNER_REPORTS);
                st.setInt(1,id_owner);
                ResultSet rs = st.executeQuery();

                while(rs.next())
                {
                    report = resultsetToReport(rs);
                    reportList.add(report);
                }
            }

        }catch(SQLException | ClassNotFoundException e) {
            reportList = null;
        }

        return reportList;
    }

    public List<ReportClass> searchPetReports(int id_pet){
        int i = 1;
        List<ReportClass> reportList = new ArrayList<>();
        ReportClass report=null;

        try{
            ConnectionDB db = new ConnectionDB();
            Connection conn = null;
            try {
                conn = db.getConnection();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            if (conn != null)
            {
                PreparedStatement st = conn.prepareStatement(QUERY_SELECT_PET_REPORTS);
                st.setInt(1,id_pet);
                ResultSet rs = st.executeQuery();

                while(rs.next())
                {
                    report = resultsetToReport(rs);
                    reportList.add(report);
                }
            }

        }catch(SQLException | ClassNotFoundException e) {
            reportList = null;
        }

        return reportList;
    }

    public int insertReport(ReportClass r){
        int result = -1;

        PreparedStatement st=null;
        try{
            if(r!=null) {
                ConnectionDB db = new ConnectionDB();
                Connection conn = db.getConnection();
                if (conn != null){
                    st = conn.prepareStatement(QUERY_INSERT_REPORT);
                    st.setInt(1,r.getIdOwner());
                    st.setInt(2,r.getIdPet());
                    st.setString(3,r.getEntryDate());
                    st.setString(4,r.getLocation());
                    st.setString(5,r.getExtra());

                    result = st.executeUpdate();
                }
            }
        } catch (SQLException | ClassNotFoundException e){
            result = 0;
        }

        return result;
    }

    private ReportClass resultsetToReport(ResultSet rs) throws SQLException {
        ReportClass n = null;

        int id = rs.getInt("id");
        int id_owner = rs.getInt("id_owner");
        int id_pet = rs.getInt("id_pet");
        String date = rs.getString("entry_date");
        String location = rs.getString("location");
        String extra = rs.getString("extra");
        int finished = rs.getInt("finished");

        n = new ReportClass(id,id_owner,id_pet,date,location,extra, finished);
        return n;
    }


}
