package cat.proven.entities.persistence;


import cat.proven.entities.ConnectionDB;
import cat.proven.entities.OwnerClass;
import cat.proven.entities.UserClass;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;




/**
 * Created by Alumne on 30/04/2016.
 */
public class UserADO {

    private final String QUERY_FIND_USER = "SELECT * FROM `user` WHERE `user_name` = ? AND `pswd` = ?";
    private final String QUERY_INSERT_USER = "INSERT INTO `user` ( `user_name`, `pswd`, `id_profile`, `email`,`active`,`image`) VALUES(?, ?, ?, ?, ?, ?)";
    private final String QUERY_INSERT_OWNER = "INSERT INTO `owner` ( `id_user`, `name`, `firstname`, `surname`,`nif`,`birthdate`,`phone_number`,`address`,`id_city_province`) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
    private final String QUERY_SEARCH_USER = "SELECT user.`id`,user.`id_profile`, user.`user_name`, user.`pswd`, user.`email`, user.`active`, user.`image`, owner.`id`, owner.`id_user`, owner.`name`, owner.`firstname`, owner.`surname`, owner.`nif`, owner.`birthdate`, owner.`registerdate`, owner.`phone_number`, owner.`address`, owner.`entry_date`, owner.`drop_out_date`, owner.`id_city_province` FROM user ,owner WHERE (user.`user_name` LIKE ? OR user.`email` LIKE ? OR owner.`name` LIKE ?) AND user.id = owner.id_user";
    private final String QUERY_MODIFY_OWNER = "UPDATE `owner` SET `name`=?, `firstname`=?, `surname`=?, `nif`=?, `birthdate`=?, `registerdate`=?, `phone_number`=?, `address`=?, `entry_date`=?, `drop_out_date`=?, `id_city_province`=? where `id_user`=?";
    private final String QUERY_MODIFY_USER = "UPDATE `user` SET `id_profile`=?, `user_name`=?, `pswd`=?, `email`=?, `active`=?, `image`=? WHERE `id`=?";
    private final String QUERY_UPDATE_USER_ACTIVE = "UPDATE `user` SET `active`=? WHERE `id`=?";
    
    public UserADO(){ }

    public UserClass getUserExist(String userName, String password)
    {
        int result = -1;
        UserClass checkuser=null;

        try{
            ConnectionDB db = new ConnectionDB();
            Connection conn = null;
            try {
                conn = db.getConnection();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            if (conn != null)
            {
                PreparedStatement st = conn.prepareStatement(QUERY_FIND_USER);
                st.setString(1,userName);
                st.setString(2,password);
                ResultSet rs = st.executeQuery();

                while(rs.next())
                {
                    checkuser = resultsetToUser(rs);
                }
            }

        }catch(Exception e) {
            checkuser = null;
        }


        return checkuser;
    }

    private UserClass resultsetToUser(ResultSet rs) throws SQLException {
        UserClass u = null;
        int id = rs.getInt("user.id");
        int id_profile = rs.getInt("user.id_profile");
        String user_name = rs.getString("user.user_name");
        String passsword = rs.getString("user.pswd");
        String email = rs.getString("user.email");
        int active = rs.getInt("user.active");
        String image = rs.getString("user.image");

        u = new UserClass(id,id_profile,user_name,passsword,email,active,image);

        return u;
    }
    
    public int register(UserClass u, OwnerClass o)
    {
        int result = -1;
        int resultUser = -1;
        PreparedStatement st=null;        
            try{                
                if(u!=null)
                {

                    ConnectionDB db = new ConnectionDB();
                    Connection conn = db.getConnection();
                    if (conn != null){
                        st = conn.prepareStatement(QUERY_INSERT_USER, Statement.RETURN_GENERATED_KEYS);
                        st.setString(1,u.getUserName());                        
                        st.setString(2,u.getPassword());
                        st.setInt(3,u.getIdProfile());
                        st.setString(4,u.getEmail());
                        st.setInt(5,u.getActive());
                        st.setString(6,u.getImage());
                        resultUser = st.executeUpdate();
                        if(resultUser==1) {
                            try (ResultSet generatedKeys = st.getGeneratedKeys()) {
                                if (generatedKeys.next()) {
                                    u.setId((int) generatedKeys.getLong(1));
                                }
                            }

                            st = conn.prepareStatement(QUERY_INSERT_OWNER);
                            st.setInt(1,u.getId());
                            st.setString(2,o.getName());
                            st.setString(3,o.getFirstname());
                            st.setString(4,o.getSurname());
                            st.setString(5,o.getNif());                            
                            st.setString(6, o.getBirthdate());                            
                            st.setString(7,o.getPhoneNumber());
                            st.setString(8,o.getAddress());
                            st.setInt(9,o.getIdCityProvince());
                            result = st.executeUpdate();

                        }


                    }
                }
            } catch (SQLException | ClassNotFoundException e){
                result = 0;
            }
        return result;
    }
    
    public int modifyOwner(OwnerClass o){
        int result = -1;
        PreparedStatement st=null;
        
        try{
            if(o!=null)
            {
                ConnectionDB db = new ConnectionDB();
                Connection conn = db.getConnection();
                
                if (conn != null){
                    st = conn.prepareStatement(QUERY_MODIFY_OWNER);
                    st.setString(1, o.getName());
                    st.setString(2, o.getFirstname());
                    st.setString(3, o.getSurname());
                    st.setString(4, o.getNif());
                    st.setString(5, o.getBirthdate());
                    st.setString(6, o.getRegisterDate());
                    st.setString(7, o.getPhoneNumber());
                    st.setString(8, o.getAddress());
                    st.setString(9, o.getEntryDate());
                    st.setString(10, o.getDropOutDate());
                    st.setInt(11, o.getIdCityProvince());
                    st.setInt(12, o.getIdUser());
                    result = st.executeUpdate();

                }
            }
        } catch (SQLException | ClassNotFoundException e){
            result = 0;
        }


        return result;
    } 
    
    public int modifyUser(UserClass u){
        int result = -1;
        PreparedStatement st=null;
        
        try{
            if(u!=null)
            {
                ConnectionDB db = new ConnectionDB();
                Connection conn = db.getConnection();
                
                if (conn != null){
                    st = conn.prepareStatement(QUERY_MODIFY_USER);
                    st.setInt(1, u.getIdProfile());
                    st.setString(2, u.getUserName());
                    st.setString(3, u.getPassword());
                    st.setString(4, u.getEmail());
                    st.setInt(5, u.getActive());
                    st.setString(6, u.getImage());
                    st.setInt(7, u.getId());
                    result = st.executeUpdate();

                }
            }
        } catch (SQLException | ClassNotFoundException e){
            result = 0;
        }


        return result;
    } 
    
    public int modifyUserActive(UserClass u){
        int result = -1;
        PreparedStatement st=null;
        
        try{
            if(u!=null)
            {
                ConnectionDB db = new ConnectionDB();
                Connection conn = db.getConnection();
                
                if (conn != null){
                    st = conn.prepareStatement(QUERY_UPDATE_USER_ACTIVE);
                    st.setInt(1, 0);
                    st.setInt(2, u.getId());
                    result = st.executeUpdate();

                }
            }
        } catch (SQLException | ClassNotFoundException e){
            result = 0;
        }


        return result;
    } 

    private OwnerClass resultsetToOwner(ResultSet rs) throws SQLException {
        OwnerClass o = null;

        UserClass user = resultsetToUser(rs);

        String name = rs.getString("owner.name");
        String firstname = rs.getString("owner.firstname");
        String surname = rs.getString("owner.surname");
        String nif = rs.getString("owner.nif");
        String birthdate = rs.getString("owner.birthdate");
        String registerdate = rs.getString("owner.registerdate");
        String phone_number = rs.getString("owner.phone_number");
        String address = rs.getString("owner.address");
        String entry_date = rs.getString("owner.entry_date");
        String drop_out_date = rs.getString("owner.drop_out_date");
        int id_city_province = rs.getInt("owner.id_city_province");


        o = new OwnerClass(user.getId(),name,firstname,surname,nif,birthdate,registerdate,phone_number,address,entry_date,drop_out_date,id_city_province);

        return o;
    }

    public List<OwnerClass> searchUsers(String toSearch)
    {
        int i = 1;
        List<OwnerClass> ownerList = new ArrayList<>();

        OwnerClass owner=null;

        try{
            ConnectionDB db = new ConnectionDB();
            Connection conn = null;
            try {
                conn = db.getConnection();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            if (conn != null)
            {
                PreparedStatement st = conn.prepareStatement(QUERY_SEARCH_USER);
                st.setString(1,"%"+toSearch+"%");
                st.setString(2,"%"+toSearch+"%");
                st.setString(3,"%"+toSearch+"%");
                ResultSet rs = st.executeQuery();

                while(rs.next())
                {
                    owner = resultsetToOwner(rs);
                    ownerList.add(owner);
                }
            }

        }catch(SQLException | ClassNotFoundException e) {
            ownerList = null;
            e.printStackTrace();
        }

        return ownerList;
    }   
}
