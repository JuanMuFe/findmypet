package cat.proven.entities.persistence;

import cat.proven.entities.AnnouncementClass;
import cat.proven.entities.ConnectionDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


/**
 * Created by Alumne on 03/05/2016.
 */
public class AnnouncementADO {

    private final String QUERY_SELECT_ANNOUNCEMENTS = "SELECT * FROM `announcement` LIMIT 5";
    private final String QUERY_SELECT_USER_ANNOUNCEMENTS = "SELECT * FROM `announcement` WHERE `id_user`=?";
    private final String QUERY_INSERT_ANNOUNCEMENT = "INSERT INTO `announcement` (`description`, `date`, `id_user`) VALUES (?,?,?)";
    private final String QUERY_DELETE_ANNOUNCEMENT = "DELETE FROM `announcement` WHERE `id` = ?";
    private final String QUERY_UPDATE_ANNOUNCEMENT = "UPDATE `announcement` SET `description`=?, `date`=?, `id_user`=? WHERE `id`=?";
    public AnnouncementADO(){ }

    public List<AnnouncementClass> getAnnouncements(){
        int i = 1;
        List<AnnouncementClass> announcementList = new ArrayList<>();
        AnnouncementClass announcement=null;
        Statement sentencia;

        try{
            ConnectionDB db = new ConnectionDB();
            Connection conn = null;
            try {
                conn = db.getConnection();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            if (conn != null)
            {
                sentencia = conn.createStatement();
                ResultSet rs = sentencia.executeQuery(QUERY_SELECT_ANNOUNCEMENTS);

                while(rs.next())
                {
                    announcement = resultsetToAnnouncement(rs);
                    announcementList.add(announcement);
                }
            }

        }catch(SQLException | ClassNotFoundException e) {
            announcementList = null;
        }

        return announcementList;
    }
    
    public int modifyAnnouncement(AnnouncementClass a)
    {
        int result = -1;

        PreparedStatement st=null;
        try{
            if(a!=null)
            {

                ConnectionDB db = new ConnectionDB();
                Connection conn = db.getConnection();
                if (conn != null){
                    st = conn.prepareStatement(QUERY_UPDATE_ANNOUNCEMENT);
                    st.setString(1,a.getDescription());
                    st.setString(2,a.getDate());
                    st.setInt(3,a.getIdUser());
                    st.setInt(4,a.getId());
                    result = st.executeUpdate();

                }
            }
        } catch (SQLException | ClassNotFoundException e){
            result = 0;
        }


        return result;
    }

    public List<AnnouncementClass> getOwnerAnnouncements(int id_user){
        int i = 1;
        List<AnnouncementClass> announcementList = new ArrayList<>();
        AnnouncementClass announcement=null;

        try{
            ConnectionDB db = new ConnectionDB();
            Connection conn = null;
            try {
                conn = db.getConnection();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            if (conn != null)
            {
                PreparedStatement st = conn.prepareStatement(QUERY_SELECT_USER_ANNOUNCEMENTS);
                st.setInt(1, id_user);
                ResultSet rs = st.executeQuery();

                while(rs.next())
                {
                    announcement = resultsetToAnnouncement(rs);
                    announcementList.add(announcement);
                }
            }

        }catch(SQLException | ClassNotFoundException e) {
            announcementList = null;
        }

        return announcementList;
    }

    public int deleteAnnouncement(int id){
        int result = -1;
        PreparedStatement st=null;

        try{
            ConnectionDB db = new ConnectionDB();
            Connection conn = db.getConnection();
            if (conn != null){
                st = conn.prepareStatement(QUERY_DELETE_ANNOUNCEMENT);
                st.setInt(1,id);
                result = st.executeUpdate();
            }            
        } catch (SQLException | ClassNotFoundException e){
            result = 0;
        }

        return result;
    }
    
    public int addAnnouncement(AnnouncementClass a)
    {
        int result = -1;

        PreparedStatement st=null;
            try{
                if(a!=null)
                {

                    ConnectionDB db = new ConnectionDB();
                    Connection conn = db.getConnection();
                    if (conn != null){
                        st = conn.prepareStatement(QUERY_INSERT_ANNOUNCEMENT);
                        st.setString(1, a.getDescription());
                        st.setString(2, a.getDate());
                        st.setInt(3, a.getIdUser());

                        result = st.executeUpdate();
                    }
                }
            } catch (SQLException | ClassNotFoundException e){
                result = 0;
            }

        return result;
    }

    private AnnouncementClass resultsetToAnnouncement(ResultSet rs) throws SQLException {
        AnnouncementClass a = null;
        int id = rs.getInt("id");
        String description = rs.getString("description");
        String date = rs.getString("date");
        int id_user = rs.getInt("id_user");

        a = new AnnouncementClass(id,description, date, id_user);
        return a;
    }

}
