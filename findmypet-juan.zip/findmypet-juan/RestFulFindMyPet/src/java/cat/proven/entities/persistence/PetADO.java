package cat.proven.entities.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cat.proven.entities.ConnectionDB;
import cat.proven.entities.OwnerClass;
import cat.proven.entities.PetClass;
import cat.proven.entities.UserClass;

/**
 * Created by Alumne on 30/04/2016.
 */
public class PetADO {

    private final String QUERY_SELECT_PET= "SELECT `id`, `id_owner`, `name`, `race`, `image`,`description` FROM `pet` WHERE (`name` LIKE ? OR `race` LIKE ?)";
    private final String QUERY_SELECT_OWNER = "SELECT `id` FROM `owner` WHERE `id_user`=?";
    private final String QUERY_INSERT_PET = "INSERT INTO `pet` ( `id_owner`, `name`, `race`, `image`,`description`) VALUES( ?,?,?,?,?)";
    private final String QUERY_UPDATE_PET = "UPDATE `pet` SET `id_owner`=?,  `name`=?, `race`=?,`image`=?,`description`=? where `id`=?";
    private final String QUERY_DELETE_PET = "DELETE FROM `pet` WHERE `id` = ?";

    public PetADO()
    {

    }



    private PetClass resultsetToPet(ResultSet rs) throws SQLException {
        PetClass p = null;
        int id = rs.getInt("id");
        int id_owner = rs.getInt("id_owner");
        String name = rs.getString("name");
        String race = rs.getString("race");
        String image = rs.getString("image");
        String description = rs.getString("description");

        p = new PetClass(id,id_owner,name,race,image,description);
        return p;
    }

    public int addPet(PetClass p)
    {
        int result = -1;
        PreparedStatement sta = null;
        PreparedStatement st=null;
            try{
                if(p!=null)
                {
                    ConnectionDB db = new ConnectionDB();
                    Connection conn = db.getConnection();
                    
                    

                    
                    if (conn != null){
                        st = conn.prepareStatement(QUERY_INSERT_PET);
                        st.setInt(1,p.getIdOwner());
                        st.setString(2,p.getName());
                        st.setString(3,p.getRace());
                        st.setString(4,p.getImage());
                        st.setString(5,p.getDescription());

                        result = st.executeUpdate();

                    }
                }
            } catch (SQLException | ClassNotFoundException e){
                result = 0;
            }


        return result;
    }

    public int modifyPet(int id_user, PetClass p)
    {
        int result = -1;
        PreparedStatement sta = null;
        PreparedStatement st=null;
        OwnerClass owner = null;
        try{
            if(p!=null)
            {

                ConnectionDB db = new ConnectionDB();
                Connection conn = db.getConnection();
                if (conn != null){
                    sta = conn.prepareStatement(QUERY_SELECT_OWNER);
                    sta.setInt(1, id_user);                            
                    ResultSet rs = st.executeQuery();
                    
                    while(rs.next()){
                        owner = resultsetToOwner(rs);                        
                    }
                    
                    st = conn.prepareStatement(QUERY_UPDATE_PET);
                    st.setInt(1,owner.getId());
                    st.setString(2,p.getName());
                    st.setString(3,p.getRace());
                    st.setString(4,p.getImage());
                    st.setString(5,p.getDescription());
                    st.setInt(6,p.getId());
                    result = st.executeUpdate();
                }
            }
            
        } catch (SQLException | ClassNotFoundException e){
            result = 0;
        }


        return result;
    }

    public int deletePet(Integer id){
        int result = -1;
        PreparedStatement st=null;

        try{
            if(id!=null)
            {
                ConnectionDB db = new ConnectionDB();
                Connection conn = db.getConnection();
                if (conn != null){
                    st = conn.prepareStatement(QUERY_DELETE_PET);
                    st.setInt(1,id);
                    result = st.executeUpdate();
                }
            }
        } catch (SQLException | ClassNotFoundException e){
            result = 0;
        }

        return result;
    }

    public List<PetClass> searchPet(String toSearch){
        String usedQuery = "";
        int result = -1;
        PetClass pet = new PetClass();
        List<PetClass> pets = new ArrayList<PetClass>();

        try{
            ConnectionDB db = new ConnectionDB();
            Connection conn = null;
            try {
                conn = db.getConnection();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            if (conn != null)
            {
                PreparedStatement st = conn.prepareStatement(QUERY_SELECT_PET);

                st.setString(1, "%"+toSearch+"%"); 
                st.setString(2, "%"+toSearch+"%"); 

                ResultSet rs = st.executeQuery();

                while(rs.next())
                {
                    pet = resultsetToPet(rs);
                    pets.add(pet);
                }
            }

        }catch(SQLException | ClassNotFoundException e) {
            pets = null;
        }

        return pets;
    }
    
    private OwnerClass resultsetToOwner(ResultSet rs) throws SQLException {
        OwnerClass o = null;

        int id_user = rs.getInt("id_user");
        o = new OwnerClass(id_user);

        return o;
    }
}

