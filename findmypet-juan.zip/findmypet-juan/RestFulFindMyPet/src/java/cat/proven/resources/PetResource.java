package cat.proven.resources;

import cat.proven.entities.PetClass;
import cat.proven.entities.UserClass;
import cat.proven.services.PetService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

//http://localhost:8080/RestFulFindMyPet/restful/pets
@Path("pets")
public class PetResource {
    
    PetService servicePet;
    
    public PetResource(){        
      
    }
    
    //http://localhost:8080/RestFulFindMyPet/restful/pets/add
    @Path("add")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response add(@FormParam("id_owner")Integer id_owner, @FormParam("name")String name, @FormParam("race")String race, @FormParam("image")String image, @FormParam("description")String description){         
        servicePet = new PetService();
       // Map<String, Object> mapping = new HashMap<>();
        PetClass pet = new PetClass(id_owner, name, race, image, description);
        int result = servicePet.addPet(pet);
        String res ="";
        if(result > 0){ res ="1";}
        else{ res="0"; }
        //mapping.put("addPet", result);
        return Response.ok(res).build();
    }
    
    //http://localhost:8080/RestFulFindMyPet/restful/pets/modify
    @Path("modify")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response modify(@FormParam("id_user")Integer id_user, @FormParam("id")Integer id, @FormParam("id_owner")Integer id_owner, @FormParam("name")String name, @FormParam("race")String race, @FormParam("image")String image, @FormParam("description")String description){         
        servicePet = new PetService();
        //Map<String, Object> mapping = new HashMap<>();
        PetClass pet = new PetClass(id, id_owner, name, race, image, description);
        int result = servicePet.modifyPet(id_user, pet); 
        String res ="";
        if(result > 0){ res ="1";}
        else{ res="0"; }
        //mapping.put("modifiedPet", result);
        return Response.ok(res).build();
    }
    
    //http://localhost:8080/RestFulFindMyPet/restful/pets/delete
    @Path("delete")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response delete(@FormParam("id")Integer id){          
        servicePet = new PetService();
        //Map<String, Object> mapping = new HashMap<>();
        int result = servicePet.deletePet(id);
        String res ="";
        if(result > 0){ res ="1";}
        else{ res="0"; }
       // mapping.put("deletedPet", result);
        return Response.ok(res).build();
    }
    
    //http://localhost:8080/RestFulFindMyPet/restful/pets/search
    @Path("search")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response search(@FormParam("toSearch")String toSearch){  
        Map<String, Object> mapping = new HashMap<>();
        servicePet = new PetService();
        List<PetClass> pets = servicePet.searchPet(toSearch);
        mapping.put("pets", pets);
        return Response.ok(mapping).build();
    }
    
}
