package cat.proven.resources;

import cat.proven.entities.NotificationClass;
import cat.proven.services.NotificationService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("notifications")
public class NotificationResource {
     NotificationService serviceNotification;
     
     public NotificationResource(){  }
     
    //http://localhost:8080/RestFulFindMyPet/restful/notifications/get
    @Path("get")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getNotifications(){
        Map<String, Object> mapping = new HashMap<>();        
        
        serviceNotification = new NotificationService();
        List<NotificationClass> notifications = serviceNotification.getNotifications();
        mapping.put("notifications", notifications);
        return Response.ok(mapping).build();              
    }
    
    //http://localhost:8080/RestFulFindMyPet/restful/notifications/getUserNotifications
    @Path("getUserNotifications")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response getUserNotifications(@FormParam("id_user")int id_user){
        Map<String, Object> mapping = new HashMap<>();          
        serviceNotification = new NotificationService();
        List<NotificationClass> notifications = serviceNotification.getUserNotifications(id_user);
        mapping.put("userNotifications", notifications);
        return Response.ok(mapping).build();              
    }
    
    //http://localhost:8080/RestFulFindMyPet/restful/notifications/add
    @Path("add")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response add(@FormParam("description")String description, @FormParam("active")int active){
        //Map<String, Object> mapping = new HashMap<>();          
        serviceNotification = new NotificationService();
        NotificationClass n = new NotificationClass(active, description);
        int result = serviceNotification.addNotification(n);
        String res ="";
        if(result > 0){ res ="1";}
        else{ res="0"; }
        //mapping.put("addNotification", result);
        return Response.ok(res).build();              
    }
    
    //http://localhost:8080/RestFulFindMyPet/restful/notifications/modify
    @Path("modify")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response modify(@FormParam("id")int id, @FormParam("description")String description, @FormParam("active")int active){
        //Map<String, Object> mapping = new HashMap<>();          
        serviceNotification = new NotificationService();
        NotificationClass n = new NotificationClass(id, active, description);
        int result = serviceNotification.modifyNotification(n);
        //mapping.put("modifyNotification", result);
        String res ="";
        if(result > 0){ res ="1";}
        else{ res="0"; }
        
        return Response.ok(res).build();              
    }
    
    //http://localhost:8080/RestFulFindMyPet/restful/notifications/modifyActive
    @Path("modifyActive")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response modifyActive(@FormParam("id")int id){
        //Map<String, Object> mapping = new HashMap<>();          
        serviceNotification = new NotificationService();
        int result = serviceNotification.modifyNotificationActive(id);
        //mapping.put("modifyActiveNotification", result);
        String res ="";
        if(result > 0){ res ="1";}
        else{ res="0"; }
        return Response.ok(res).build();              
    }
}
