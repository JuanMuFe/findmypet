package cat.proven.resources;

import cat.proven.entities.ParkClass;
import cat.proven.services.ParkService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("parks")
public class ParkResource {
    ParkService servicePark;
    
    public ParkResource(){}
    
    //http://localhost:8080/RestFulFindMyPet/restful/parks/get
    @Path("get")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response get(){       
        Map<String, Object> mapping = new HashMap<>();
        servicePark = new ParkService();
        List<ParkClass> parks = servicePark.get();
        mapping.put("parks", parks);
        return Response.ok(mapping).build();              
    }
    
    //http://localhost:8080/RestFulFindMyPet/restful/parks/add
    @Path("add")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response add(@FormParam("name")String name, @FormParam("address")String address, @FormParam("id_city_province")int id_city_province){
        ParkClass p = new ParkClass(name, address, id_city_province);            
        
        servicePark = new ParkService();
        int result = servicePark.add(p);
        String res ="";
        if(result > 0){ res ="1";}
        else{ res="0"; }
        return Response.ok(res).build();              
    }
    
    //http://localhost:8080/RestFulFindMyPet/restful/parks/modify
    @Path("modify")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response modify(@FormParam("id")int id, @FormParam("name")String name, @FormParam("address")String address,@FormParam("id_city_province")int id_city_province){
        ParkClass p = new ParkClass(id, name, address, id_city_province);            
        
        servicePark = new ParkService();
        int result = servicePark.modify(p);
        String res ="";
        if(result > 0){ res ="1";}
        else{ res="0"; }
        return Response.ok(res).build();              
    } 
    
    //http://localhost:8080/RestFulFindMyPet/restful/parks/delete
    @Path("delete")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response delete(@FormParam("id")int id){   
        servicePark = new ParkService();
        int result = servicePark.delete(id);
        String res = "";
        if(result > 0){ res = "1";}
        else{ res = "0"; }
        return Response.ok(res).build();              
    }
    
}
