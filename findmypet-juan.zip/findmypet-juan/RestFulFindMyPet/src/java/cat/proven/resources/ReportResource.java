package cat.proven.resources;

import cat.proven.entities.PetClass;
import cat.proven.entities.ReportClass;
import cat.proven.services.ReportService;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

//http://localhost:8080/RestFulFindMyPet/restful/reports
@Path("reports")
public class ReportResource {
    ReportService serviceReport;
    
    public ReportResource(){ }
    
    //http://localhost:8080/RestFulFindMyPet/restful/reports/add
    @Path("add")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response add(@FormParam("id_owner")Integer id_owner, @FormParam("id_pet")Integer id_pet, @FormParam("location")String location, @FormParam("extra")String extra){         
        serviceReport = new ReportService();
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Calendar cal = Calendar.getInstance();
        //Map<String, Object> mapping = new HashMap<>();
        ReportClass report = new ReportClass(id_owner, id_pet, dateFormat.format(cal.getTime()), location, extra, 0);
        int result = serviceReport.addReport(report);
        String res ="";
        if(result > 0){ res ="1";}
        else{ res="0"; }
        //mapping.put("addReport", result);
        return Response.ok(res).build();
    }
    
    //http://localhost:8080/RestFulFindMyPet/restful/reports/modify
    @Path("modify")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response modify(@FormParam("id")Integer id, @FormParam("id_owner")Integer id_owner, @FormParam("id_pet")Integer id_pet, @FormParam("entry_date")String entry_date, @FormParam("location")String location, @FormParam("extra")String extra, @FormParam("finished")Integer finished){         
        serviceReport = new ReportService();
       //Map<String, Object> mapping = new HashMap<>();
        ReportClass report = new ReportClass(id, id_owner, id_pet, entry_date, location, extra, finished);
        int result = serviceReport.modifyReport(report);
        String res ="";
        if(result > 0){ res ="1";}
        else{ res="0"; }
        //mapping.put("modifyReport", result);
        return Response.ok(res).build();
    }
    
    //http://localhost:8080/RestFulFindMyPet/restful/reports/modifyFinished
    @Path("modifyFinished")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response mofidyFinished(@FormParam("id")Integer id){         
        serviceReport = new ReportService();
        //Map<String, Object> mapping = new HashMap<>();
        ReportClass report = new ReportClass(id);
        int result = serviceReport.modifyReportFinished(report);
        String res ="";
        if(result > 0){ res ="1";}
        else{ res="0"; }
        //mapping.put("modifyReport", result);
        return Response.ok(res).build();
    }
    
    //http://localhost:8080/RestFulFindMyPet/restful/reports/searchOwnerReports
    @Path("searchOwnerReports")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response searchOwnerReports(@FormParam("id_owner")Integer id_owner){         
        serviceReport = new ReportService();
        Map<String, Object> mapping = new HashMap<>();
        List<ReportClass> result = serviceReport.searchOwnerReports(id_owner);
        mapping.put("ownerReports", result);
        return Response.ok(mapping).build();
    }
    
    //http://localhost:8080/RestFulFindMyPet/restful/reports/searchPetReports
    @Path("searchPetReports")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response searchPetReports(@FormParam("id_pet")Integer id_pet){         
        serviceReport = new ReportService();
        Map<String, Object> mapping = new HashMap<>();
        List<ReportClass> result = serviceReport.searchPetReports(id_pet);
        mapping.put("petReports", result);
        return Response.ok(mapping).build();
    }
}
