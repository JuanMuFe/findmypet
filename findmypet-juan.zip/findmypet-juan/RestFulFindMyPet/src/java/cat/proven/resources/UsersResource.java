package cat.proven.resources;


import cat.proven.entities.OwnerClass;
import cat.proven.entities.UserClass;
import cat.proven.services.UserService;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 *
 * @author AMS
 * Exemple Accés al servei GET: 
 * http://localhost:8080/RestFulFindMyPet/restful/users
 */
@Path("users")
public class UsersResource {
    
    UserService serviceUser;
 
    
    public UsersResource(){        
      
    }
    
//http://localhost:8080/RestFulFindMyPet/restful/users/login/admin/admin
    //@Path("login")
    @Path("login") ///{userName}/{password}
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response login(@FormParam("username")String userName,@FormParam("password")String password){
        Map<String, Object> mapping = new HashMap<>();
        
        serviceUser = new UserService();
        UserClass user = serviceUser.login(userName,password);
        mapping.put("user", user);
        return Response.ok(mapping).build();              
    }
    
    //http://localhost:8080/RestFulFindMyPet/restful/users/register/juanmunoz/juanito/juanmf1894@gmail.com/Juan/Munoz/Fernandez/53314249L/1994-03-18 00:00:00/722180394/C-AngelArano/1
    @Path("register") ///{username}/{pswd}/{email}/{name}/{firstname}/{surname}/{nif}/{birthdate}/{phone_number}/{address}/{id_city_province}
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response register(@FormParam("username")String username, @FormParam("pswd")String pswd,
            @FormParam("email")String email, @FormParam("name")String name, @FormParam("firstname")String firstname, 
            @FormParam("surname")String surname, @FormParam("nif")String nif, @FormParam("birthdate")String birthdate,
            @FormParam("phone_number")String phone_number, @FormParam("address")String address, 
            @FormParam("id_city_province")int id_city_province){     /*@PathParam("username")String username, @PathParam("pswd")String pswd,
            @PathParam("email")String email, @PathParam("name")String name, @PathParam("firstname")String firstname, 
            @PathParam("surname")String surname, @PathParam("nif")String nif, @PathParam("birthdate")String birthdate,
            @PathParam("phone_number")String phone_number, @PathParam("address")String address, 
            @PathParam("id_city_province")int id_city_province*/
        
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Calendar cal = Calendar.getInstance();
        Map<String, Object> mapping = new HashMap<>();
        
        UserClass user = new UserClass(2, username, pswd, email, 1);
        OwnerClass owner = new OwnerClass(name, firstname, surname, nif, birthdate, dateFormat.format(cal.getTime()), phone_number, address, dateFormat.format(cal.getTime()), id_city_province);
                
        serviceUser = new UserService();
        int result = serviceUser.register(user,owner);
        String res ="";
        if(result > 0){ res ="1";}
        else{ res="0"; }
        //mapping.put("register", res);
        return Response.ok(res).build();
    }
    
    //http://localhost:8080/RestFulFindMyPet/restful/users/search
    @Path("search")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response search(@FormParam("toSearch")String toSearch){
        Map<String, Object> mapping = new HashMap<>();        
        
        serviceUser = new UserService();
        List<OwnerClass> owners = serviceUser.search(toSearch);
        mapping.put("owners", owners);
        return Response.ok(mapping).build();              
    } 
    
    
    //http://localhost:8080/RestFulFindMyPet/restful/users/modifyOwner
    @Path("modifyOwner")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response modifyOwner(@FormParam("id_user")int id_user, @FormParam("name")String name,
            @FormParam("firstname")String firstname, @FormParam("surname")String surname,@FormParam("nif")String nif,
            @FormParam("birthdate")String birthdate,@FormParam("registerdate")String registerdate,
            @FormParam("phone_number")String phone_number,@FormParam("address")String address,@FormParam("entry_date")String entry_date,
            @FormParam("drop_out_date")String drop_out_date,@FormParam("id_city_province")int id_city_province){
                
        OwnerClass o = new OwnerClass(id_user, name, firstname, surname, nif, birthdate, registerdate, phone_number, address, entry_date, drop_out_date, id_city_province);
        
        serviceUser = new UserService();
        int result = serviceUser.modifyOwner(o);
        String res ="";
        if(result > 0){ res ="1";}
        else{ res="0"; }
        return Response.ok(res).build();              
    } 
    
    //http://localhost:8080/RestFulFindMyPet/restful/users/modifyUser
    @Path("modifyUser")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response modifyUser(@FormParam("id")int id, @FormParam("id_profile")int id_profile, @FormParam("user_name")String user_name,
            @FormParam("pswd")String pswd, @FormParam("email")String email, @FormParam("active")int active,
            @FormParam("image")String image){
        UserClass u = new UserClass(id, id_profile, user_name, pswd, email, active, image); 
        serviceUser = new UserService();
        int result = serviceUser.modifyUser(u);
        String res ="";
        if(result > 0){ res ="1";}
        else{ res="0"; }
        return Response.ok(res).build();              
    } 
    
    
    
    //http://localhost:8080/RestFulFindMyPet/restful/users/modifyUserActive
    @Path("modifyUserActive")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response modifyUserActive(@FormParam("id")int id){
                
        UserClass u = new UserClass(id);
        
        serviceUser = new UserService();
        int result = serviceUser.modifyUserActive(u);
        String res ="";
        if(result > 0){ res ="1";}
        else{ res="0"; }
        return Response.ok(res).build();              
    } 
    
    
    /*
    // 
    
    // http://localhost:8080/ActivitatsRestFulCode/v1/students/10/
    @Path("{id}")
    @GET
    public Response findStudentById(@PathParam("id") int id){
        UserClass s = serviceStudent.findById(id);
        if(s == null) 
            return Response.status(Response.Status.NOT_FOUND).build();
        else
            return Response.ok(s).build();
    }
    
    
    @POST
    public Response addStudent(
            @FormParam("name") String name, 
            @FormParam("lastname") String lastname){
        
        if(name == null || name.equals("")){
            ApplicationException ex = new ApplicationException("El paràmetre name és obligatori");
            return Response.status(Response.Status.BAD_REQUEST).entity(ex).build();
        }

        if(lastname == null || lastname.equals("")){
            ApplicationException ex = new ApplicationException("El paràmetre lastname és obligatori");
            return Response.status(Response.Status.BAD_REQUEST).entity(ex).build();
        }
            
        
        UserClass s = new UserClass(0, name, lastname);
        s = serviceStudent.add(s);
        
        return Response.ok(s).build();
    }
    
    @Path("{id}")
    @PUT
    public Response modifyStudent(
            @PathParam("id") int id,
            @FormParam("name") String name, 
            @FormParam("lastname") String lastname){
        
        UserClass s = serviceStudent.findById(id);
        if(s == null)
            return Response.status(Response.Status.NOT_FOUND).build();
        
        if(name == null || name.equals("")){
            ApplicationException ex = new ApplicationException("El paràmetre name és obligatori");
            return Response.status(Response.Status.BAD_REQUEST).entity(ex).build();
        }

        if(lastname == null || lastname.equals("")){
            ApplicationException ex = new ApplicationException("El paràmetre lastname és obligatori");
            return Response.status(Response.Status.BAD_REQUEST).entity(ex).build();
        }
        
        s.setName(name);
        s.setLastname(lastname);
        return Response.ok().build();
        
    }
    
    @DELETE
    @Path("{id}")
    public Response deleteStudent(@PathParam("id") int id){
        UserClass s = serviceStudent.findById(id);
        if(s == null) 
            return Response.status(Response.Status.NOT_FOUND).build();
        else{
            serviceStudent.remove(s);
            return Response.ok().build();
        }            
    }
    
    @Path("{id}/courses")
    @GET
    public Response getCoursesByStudentId(@PathParam("id") int id){
        UserClass s = serviceStudent.findById(id);
        if(s == null)
            return Response.status(Response.Status.NOT_FOUND).build();
        else {
            ArrayList<Course> cursos = s.getCourses();
            GenericEntity<ArrayList<Course>> entity =
                    new GenericEntity<ArrayList<Course>>(cursos) {};
                    
            return Response
                    .ok()
                    .entity(entity)
                    .build();
        }
    }
    
    @Path("{id_student}/courses/{id_course}")
    @POST
    public Response addStudentToCourse(
            @PathParam("id_student") int idStudent, 
            @PathParam("id_course") int idCourse){
        
        UserClass s = serviceStudent.findById(idStudent);
        if(s == null)
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .build();
        
        Course c = courseService.findById(idCourse);
        if(c == null)
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .build();
        
        s.getCourses().add(c);
        return Response.ok().build();
    }
    */
    
}
