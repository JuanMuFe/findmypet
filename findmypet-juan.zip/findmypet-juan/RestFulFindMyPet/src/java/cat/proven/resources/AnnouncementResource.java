package cat.proven.resources;

import cat.proven.entities.AnnouncementClass;
import cat.proven.services.AnnouncementService;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("announcements")
public class AnnouncementResource {
    
    AnnouncementService serviceAnnouncement;
    
    public AnnouncementResource(){  }
    
    
    //http://localhost:8080/RestFulFindMyPet/restful/announcements/getAnnouncements
    @Path("getAnnouncements")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAnnouncements(){
        Map<String, Object> mapping = new HashMap<>();        
        
        serviceAnnouncement = new AnnouncementService();
        List<AnnouncementClass> announcements = serviceAnnouncement.getAnnouncements();
        mapping.put("announcements", announcements);
        return Response.ok(mapping).build();              
    } 
    
    //http://localhost:8080/RestFulFindMyPet/restful/announcements/getUserAnnouncements/3
    @Path("getUserAnnouncements")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response getUserAnnouncements(@FormParam("id_user")int id_user){
        Map<String, Object> mapping = new HashMap<>();             
        serviceAnnouncement = new AnnouncementService();
        List<AnnouncementClass> announcements = serviceAnnouncement.getUserAnnouncements(id_user);
        mapping.put("userAnnouncements", announcements);
        return Response.ok(mapping).build();              
    } 
    
    //http://localhost:8080/RestFulFindMyPet/restful/announcements/add/
    @Path("add")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response insert(@FormParam("description")String description, @FormParam("id_user")int id_user){
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Calendar cal = Calendar.getInstance();
        //Map<String, Object> mapping = new HashMap<>();             
        serviceAnnouncement = new AnnouncementService();
        AnnouncementClass a = new AnnouncementClass(description, dateFormat.format(cal.getTime()), id_user);
        int result = serviceAnnouncement.insertAnnouncement(a);
        String res ="";
        if(result > 0){ res ="1";}
        else{ res="0"; }
        //mapping.put("addAnnouncements", result);
        return Response.ok(res).build();              
    } 
    
     //http://localhost:8080/RestFulFindMyPet/restful/announcements/modify
    @Path("modify")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response delete(@FormParam("id")int id, @FormParam("description")String description, @FormParam("id_user")int id_user){
        //Map<String, Object> mapping = new HashMap<>();   
        serviceAnnouncement = new AnnouncementService();
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Calendar cal = Calendar.getInstance();
        AnnouncementClass a = new AnnouncementClass(id, description, dateFormat.format(cal.getTime()), id_user);
        int result = serviceAnnouncement.modifyAnnouncement(a);
        String res ="";
        if(result > 0){ res ="1";}
        else{ res="0"; }
        //mapping.put("modifyAnnouncement", result);
        return Response.ok(res).build();              
    }
}
